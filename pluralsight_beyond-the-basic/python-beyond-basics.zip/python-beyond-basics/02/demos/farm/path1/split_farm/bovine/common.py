def ruminate():
    return 'chomp!'

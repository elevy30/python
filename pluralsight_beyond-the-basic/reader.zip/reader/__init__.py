from .reader import Reader

# print("python import the reader package")
print('inside reader init --> name {}'.format(__name__))
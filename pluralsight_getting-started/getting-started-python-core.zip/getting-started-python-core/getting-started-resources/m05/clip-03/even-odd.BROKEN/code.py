def even_or_odd(n):
    if n % 2 == 0:
        print("even")
        return
    print("odd")

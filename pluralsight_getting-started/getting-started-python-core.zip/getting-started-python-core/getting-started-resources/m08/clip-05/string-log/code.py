# exceptional.py

from math import log

def string_log(s):
    v = convert(s)
    return log(v)

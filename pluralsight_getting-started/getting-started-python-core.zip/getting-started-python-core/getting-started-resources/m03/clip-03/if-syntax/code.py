if expression:
    block
